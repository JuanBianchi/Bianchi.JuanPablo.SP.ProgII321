
package inventariopersonajes;

import static config.AppConstants.*;
import java.io.IOException;
import java.util.List;
import modelo.Clase;
import modelo.Inventario;
import modelo.Personaje;
import servicio.PersonajeService;


public class Test {


    public static void main(String[] args) {
        Inventario<Personaje> personajes = new Inventario();
        PersonajeService.hardcodearPersonajes(personajes);
        //personajes.mostrarContenido();
        //personajes.mostrarContenido((p1, p2) -> Integer.compare(p1.getNivel(), p2.getNivel()) );
        
        System.out.println("--------------------------");
        System.out.println("Personajes filtrados por: MAGOS");
        List<Personaje> magos = personajes.filtrar( p -> p.getClase().equals(Clase.MAGO));
        magos.forEach(System.out::println);
        System.out.println("-----------");
        List<Personaje> personajesNivelesAumentados = personajes.transformar(p -> {
            p.aumentarNivel(5);
            return p;
        });
        System.out.println("Niveles aumentados");
        personajesNivelesAumentados.forEach(System.out::println);
        System.out.println("-------------");
        personajes.guardarPersonajesCSV(PATH_CSV);
        System.out.println("Lista de personajes guardada en CSV.");
        personajes.eliminar(0);
        personajes.eliminar(1);
        personajes.eliminar(2);
        System.out.println("-------------");
        System.out.println("Lista de personajes despues de borrarse algunos personajes:");
        personajes.mostrarContenido();
        System.out.println("-------------");
        System.out.println("Lista de Personajes recuperada");
        Inventario<Personaje> inventarioRecuperado = new Inventario<>();
        inventarioRecuperado.cargarPersonajeCSV(PATH_CSV);
        inventarioRecuperado.mostrarContenido();
        System.out.println("--------------");
        personajes.serializarArchivoPersonajes(PATH_SERIAL);
        
        
        
    }
    
}
