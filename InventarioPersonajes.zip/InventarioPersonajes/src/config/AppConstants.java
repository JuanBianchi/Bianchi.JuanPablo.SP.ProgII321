
package config;


public class AppConstants {
    public static final String PATH_FILE = "src/data/";
    public static final String PATH_CSV = PATH_FILE + "personajes.csv";
    public static final String PATH_SERIAL = PATH_FILE + "personajes.dat";
}
