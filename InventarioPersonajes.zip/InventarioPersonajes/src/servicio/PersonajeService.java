
package servicio;

import java.util.List;
import modelo.Clase;
import modelo.Inventario;
import modelo.Personaje;


public class PersonajeService {
    
    public static void hardcodearPersonajes(Inventario<? super Personaje> inventario)
    {
        inventario.agregarItem(new Personaje(1, "Gandalf", Clase.MAGO, 50));
        inventario.agregarItem(new Personaje(2, "Aragorn", Clase.GUERRERO, 20));
        inventario.agregarItem(new Personaje(3, "Legolas", Clase.ARQUERO, 25));
        inventario.agregarItem(new Personaje(4, "Frodo", Clase.GUERRERO, 10));
        inventario.agregarItem(new Personaje(5, "Saruman", Clase.MAGO, 40));
        inventario.agregarItem(new Personaje(6, "Robin Hood", Clase.ARQUERO, 30));
    }
    
    public static void listarPersonajes(List<? super Personaje> personajes){
        System.out.println("Lista de personajes: ");
        for(Object o : personajes){
            if(o instanceof Personaje p)
            {
                System.out.println(p);
            }
            
        }
    }
    
}
