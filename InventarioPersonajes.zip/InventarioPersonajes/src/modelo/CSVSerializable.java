
package modelo;



public interface CSVSerializable {
    
    
}
