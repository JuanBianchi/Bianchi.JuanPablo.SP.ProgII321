
package modelo;

import java.io.Serializable;


public class Personaje implements Comparable<Personaje>, CSVSerializable, Serializable{
    
    private static final Long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private Clase clase;
    private int nivel;

    public Personaje(int id, String nombre, Clase clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    }

    public Clase getClase() {
        return clase;
    }

    public void aumentarNivel(int nivel) {
        this.nivel = this.nivel + nivel;
    }
    
    

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Clase: " + clase + ", Nivel: " + nivel;
    }

    @Override
    public int compareTo(Personaje p) {
        return nombre.compareTo(p.nombre);
    }
    
    @Override
    public boolean equals(Object o )
    {
        if(o == null)
        {
            return false;
        }
        if(o instanceof Personaje p)
        {
            return Integer.compare(this.id, p.id) == 0;
        }
        if(o instanceof Clase t)
        {
            return clase.equals(t);
        }
        
        return false;
    }
    
    
    public static Personaje fromCSV(String datosPersonaje)
    {
        Personaje toReturn = null;
        
        String[] values = datosPersonaje.split(",");
        if(values.length == 4)
        {
            int id = Integer.parseInt(values[0]);
            String nombre = values[1];
            Clase clase = Clase.valueOf(values[2]);
            int nivel = Integer.parseInt(values[3]);
                    
            toReturn = new Personaje(id, nombre, clase, nivel);
            
        }
        
        return toReturn;
    }
    
    public String toCSV(){
        return id + "," + nombre + "," + clase + "," + nivel;
    }
    
    
    
    
    
}
