
package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public class Inventario<T> implements Iterable<T>{

    private List<T> items = new ArrayList<>();
    
    
    public void agregarItem(T item) {
        if(item == null){
            throw new IllegalArgumentException();
        }
        items.add(item);
        
    }

    public void eliminar(int indice) {
        checkRango(indice);
        this.items.remove(indice);
    }

    
    private void checkRango(int indice)
    {
        if(indice < 0 || indice >= items.size())
        {
            throw new IndexOutOfBoundsException("El elemento es menor a 0 o es mayor al tamaño de la lista");
        }
    }
    
    @Override
    public Iterator<T> iterator()
    {
        if(!items.isEmpty() && items.get(0) instanceof Comparable)
        {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return items.iterator();
    }
    
    
    public Iterator<T> iterator(Comparator<? super T> comparator){
        
        List<T> listacopia = new ArrayList<>(items);
        listacopia.sort(comparator);
        
        return listacopia.iterator();
    }
    
    
    public void mostrarContenido()
    {
        Iterator<T> itProd = iterator((Comparator<? super T>) Comparator.naturalOrder());
        
        while(itProd.hasNext())
        {
            System.out.println(itProd.next());
        }
    }
    
    public void mostrarContenido(Comparator<? super T> comparador)
    {
        Iterator<T> itProd = iterator(comparador);
        
        while(itProd.hasNext())
        {
            System.out.println(itProd.next());
        }
    }
    
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> listaNueva = new ArrayList();
        for(T item : items)
        {
            if(criterio.test(item))
            {
                listaNueva.add(item);
            }
        }    
        return listaNueva;
    }
    
    
    public List<T> transformar(Function<? super T, ? extends T> transformacion)
    {
        List<T> listacopia = new ArrayList<>();
        for(T item : items)
        {
            listacopia.add(transformacion.apply(item));
        }
        
        return listacopia;
    }
    
    
    public void guardarPersonajesCSV(String nombreArchivo) {
    
        
        File archivo = new File(nombreArchivo);
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){ 
            
            bw.write("id,nombre,clase,nivel\n");
            for(T item : items)
            {
                if(item instanceof Personaje p)
                {
                    bw.write(p.toCSV() + "\n");
                }
                
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        
    }
    
    public void cargarPersonajeCSV(String path)
    {
        File archivo = new File(path);
        
        try(BufferedReader br = new BufferedReader(new FileReader(archivo))){
            
            String linea;
            br.readLine();
            while((linea = br.readLine()) != null)
            {
                if(linea.endsWith("\n")){
                    linea = linea.substring(linea.length() - 1);
                }
                Personaje personaje = Personaje.fromCSV(linea);

                if (personaje != null) {
                    this.agregarItem((T) personaje);
                }    
            }
            
        }   
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        
    }
    
    public void serializarArchivoPersonajes(String archivo){
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(archivo)))
        {
            salida.writeObject(items);
            
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }
    
    
}
