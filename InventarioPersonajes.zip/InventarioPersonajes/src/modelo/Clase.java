
package modelo;


public enum Clase {
    GUERRERO,
    MAGO,
    ARQUERO;
}
